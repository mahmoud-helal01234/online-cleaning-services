<html>
    <head>
        <link rel="stylesheet" href="https://unpkg.com/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/services/service-5/assets/css/service-5.css">

    </head>
    <body>
    <x-navbar />


        <div class="modal fade" id="cart-modal" tabindex="-1"
            aria-labelledby="cartModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Cart</h5>
                        <button type="button" class="btn-close"
                            data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="card">

                            <!-- Product Info -->
                            <div class="card-body text-center">
                                <div class="cart-options" id="cart-options">

                                </div>
                                <!-- inputs for cart -->
                                <div>
                                    <div class="form-group row cart-input">
                                        <label for="name"
                                            class="col-sm-2 col-form-label">Name</label>
                                        <div class="col-sm-10">
                                            <input class="form-control"
                                                type="text"
                                                placeholder="Please enter your name"
                                                name="name">
                                        </div>

                                    </div>

                                    <div class="form-group row cart-input">
                                        <label for="name"
                                            class="col-sm-2 col-form-label">Phone
                                            number</label>
                                        <div class="col-sm-10">
                                            <input class="form-control"
                                                type="text"
                                                placeholder="Please enter your phone number"
                                                name="phoneNumber">
                                        </div>

                                    </div>

                                    <div class="form-group row cart-input">
                                        <label for="address"
                                            class="col-sm-2 col-form-label">
                                            Address
                                        </label>
                                        <div class="col-sm-10">
                                            <input class="form-control"
                                                type="text"
                                                placeholder="Please enter your detailed address"
                                                name="address">
                                        </div>

                                    </div>

                                    <div class="form-group row cart-input">
                                        <label for="address"
                                            class="col-sm-2 col-form-label">
                                            Prefered pickup time
                                        </label>
                                        <div class="col-sm-5">
                                            <input class="form-control"
                                                type="date"
                                                placeholder="Please enter your detailed address"
                                                name="date">
                                        </div>

                                        <div class="col-sm-5">
                                            <input class="form-control"
                                                type="time"
                                                placeholder="Please enter your detailed address"
                                                name="time">
                                        </div>

                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Add to
                            cart</button>
                    </div>
                </div>
            </div>
        </div>

        <section class="bg-light py-3 py-md-5 py-xl-8">
            <div class="container overflow-hidden">
              <div class="row gy-4 gy-md-5 gy-lg-0 align-items-center">
                <div class="col-12 col-lg-5">
                  <div class="row">
                    <div class="col-12 col-xl-11">
                      <h3 class="fs-6 text-secondary mb-3 mb-xl-4 text-uppercase">What We Do?</h3>
                      <h2 class="display-5 mb-3 mb-xl-4">We are giving you perfect solutions with our proficient services.</h2>
                      <p class="mb-3 mb-xl-4">Our comprehensive suite of services is designed to meet your every need and help you thrive in today's dynamic business landscape. Contact us today to embark on a journey of growth, innovation, and unparalleled support. Your success is our priority.</p>
                      <a href="#!" class="btn bsb-btn-2xl btn-primary rounded-pill">Call us</a>
                      <a href="#!" style="background-color:rgb(9, 217,9)" class="text-white btn bsb-btn-2xl rounded-pill">Message us on whatsapp</a>

                    </div>
                  </div>
                </div>
                <div class="col-12 col-lg-7 overflow-hidden">
                  <div class="row gy-4">
                    <div class="col-12 col-sm-6">
                      <div class="card border-0 border-bottom border-primary shadow-sm">
                        <div class="card-body text-center p-4 p-xxl-5">
                          <svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" fill="currentColor" class="bi bi-textarea-resize text-primary mb-4" viewBox="0 0 16 16">
                            <path d="M0 4.5A2.5 2.5 0 0 1 2.5 2h11A2.5 2.5 0 0 1 16 4.5v7a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 0 11.5v-7zM2.5 3A1.5 1.5 0 0 0 1 4.5v7A1.5 1.5 0 0 0 2.5 13h11a1.5 1.5 0 0 0 1.5-1.5v-7A1.5 1.5 0 0 0 13.5 3h-11zm10.854 4.646a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708l3-3a.5.5 0 0 1 .708 0zm0 2.5a.5.5 0 0 1 0 .708l-.5.5a.5.5 0 0 1-.708-.708l.5-.5a.5.5 0 0 1 .708 0z" />
                          </svg>
                          <h4 class="mb-4">Market Research</h4>
                          <p class="mb-4 text-secondary">We can help you to understand your target market and identify new opportunities for growth. We offer a variety of research services.</p>
                          <!-- <a href="#!" class="fw-bold text-decoration-none link-primary">
                            Learn More
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-short" viewBox="0 0 16 16">
                              <path fill-rule="evenodd" d="M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z" />
                            </svg>
                          </a> -->
                        </div>
                      </div>
                    </div>
                    <div class="col-12 col-sm-6">
                      <div class="card border-0 border-bottom border-primary shadow-sm">
                        <div class="card-body text-center p-4 p-xxl-5">
                          <svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" fill="currentColor" class="bi bi-tablet text-primary mb-4" viewBox="0 0 16 16">
                            <path d="M12 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h8zM4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H4z" />
                            <path d="M8 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" />
                          </svg>
                          <h4 class="mb-4">Web Design</h4>
                          <p class="mb-4 text-secondary">We can help you to create a visually appealing and user-friendly website. We take into account your brand identity and target audience.</p>
                          <!-- <a href="#!" class="fw-bold text-decoration-none link-primary">
                            Learn More
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-short" viewBox="0 0 16 16">
                              <path fill-rule="evenodd" d="M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z" />
                            </svg>
                          </a> -->
                        </div>
                      </div>
                    </div>
                    <div class="col-12 col-sm-6">
                      <div class="card border-0 border-bottom border-primary shadow-sm">
                        <div class="card-body text-center p-4 p-xxl-5">
                          <svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" fill="currentColor" class="bi bi-repeat text-primary mb-4" viewBox="0 0 16 16">
                            <path d="M11 5.466V4H5a4 4 0 0 0-3.584 5.777.5.5 0 1 1-.896.446A5 5 0 0 1 5 3h6V1.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384l-2.36 1.966a.25.25 0 0 1-.41-.192Zm3.81.086a.5.5 0 0 1 .67.225A5 5 0 0 1 11 13H5v1.466a.25.25 0 0 1-.41.192l-2.36-1.966a.25.25 0 0 1 0-.384l2.36-1.966a.25.25 0 0 1 .41.192V12h6a4 4 0 0 0 3.585-5.777.5.5 0 0 1 .225-.67Z" />
                          </svg>
                          <h4 class="mb-4">Daily Updates</h4>
                          <p class="mb-4 text-secondary">We provide our clients with daily updates on their business performance. This includes data on website traffic and sales.</p>
                          <!-- <a href="#!" class="fw-bold text-decoration-none link-primary">
                            Learn More
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-short" viewBox="0 0 16 16">
                              <path fill-rule="evenodd" d="M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z" />
                            </svg>
                          </a> -->
                        </div>
                      </div>
                    </div>
                    <div class="col-12 col-sm-6">
                      <div class="card border-0 border-bottom border-primary shadow-sm">
                        <div class="card-body text-center p-4 p-xxl-5">
                          <svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" fill="currentColor" class="bi bi-shield-check text-primary mb-4" viewBox="0 0 16 16">
                            <path d="M5.338 1.59a61.44 61.44 0 0 0-2.837.856.481.481 0 0 0-.328.39c-.554 4.157.726 7.19 2.253 9.188a10.725 10.725 0 0 0 2.287 2.233c.346.244.652.42.893.533.12.057.218.095.293.118a.55.55 0 0 0 .101.025.615.615 0 0 0 .1-.025c.076-.023.174-.061.294-.118.24-.113.547-.29.893-.533a10.726 10.726 0 0 0 2.287-2.233c1.527-1.997 2.807-5.031 2.253-9.188a.48.48 0 0 0-.328-.39c-.651-.213-1.75-.56-2.837-.855C9.552 1.29 8.531 1.067 8 1.067c-.53 0-1.552.223-2.662.524zM5.072.56C6.157.265 7.31 0 8 0s1.843.265 2.928.56c1.11.3 2.229.655 2.887.87a1.54 1.54 0 0 1 1.044 1.262c.596 4.477-.787 7.795-2.465 9.99a11.775 11.775 0 0 1-2.517 2.453 7.159 7.159 0 0 1-1.048.625c-.28.132-.581.24-.829.24s-.548-.108-.829-.24a7.158 7.158 0 0 1-1.048-.625 11.777 11.777 0 0 1-2.517-2.453C1.928 10.487.545 7.169 1.141 2.692A1.54 1.54 0 0 1 2.185 1.43 62.456 62.456 0 0 1 5.072.56z" />
                            <path d="M10.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z" />
                          </svg>
                          <h4 class="mb-4">Free Support</h4>
                          <p class="mb-4 text-secondary">We offer free support to all of our clients. This means that you can always get help when you need it, no matter what time it is.</p>
                          <!-- <a href="#!" class="fw-bold text-decoration-none link-primary">
                            Learn More
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-right-short" viewBox="0 0 16 16">
                              <path fill-rule="evenodd" d="M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8z" />
                            </svg>
                          </a> -->
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
    </body>
</html>
<script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>

        <script src="js/index.js"></script>
<!-- Service 5 - Bootstrap Brain Component -->
