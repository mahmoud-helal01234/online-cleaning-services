<div class="floating-icons">
            <a href="tel:+971506689921" class="btn btn-call" target="_blank">

                <i class="fa fa-phone floating-icon"
                    style="color:rgb(5, 145,229)"></i>
            </a>
            <a href="https://wa.me/+971506689921" class="btn btn-whatsapp"
                target="_blank">
                <i class="fa-brands fa-whatsapp floating-icon"
                    style="color:rgb(9, 217,9)"></i>
            </a>

        </div>
