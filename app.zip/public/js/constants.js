const preImageUrl = "https://aquacare-laundry.com/";

const preApiUrl = "https://aquacare-laundry.com/api/";