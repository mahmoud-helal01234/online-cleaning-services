<?php

    return [
        
        "created"   => "Created successfully",
        "added"     => "Added successfully",
        "updated"   =>  "Updated successfully"

    ];
