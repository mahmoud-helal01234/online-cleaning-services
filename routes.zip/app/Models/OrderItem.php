<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class OrderItem extends Model
{

    use HasFactory, SoftDeletes;

    protected $fillable = [

        'id','order_id', 'name', 'quantity', 'price' , 'product_option_id', 'product_id'
    ];
    protected $hidden = ['deleted_at'];

    public $timestamps = false;


    public function order()
    {

        return $this->belongsTo(ClientOrder::class, 'order_id', 'order_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id', 'id');
    }
    public function productOption()
    {
        return $this->belongsTo(ProductOption::class, 'product_option_id', 'id');
    }
}
