<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Invoice extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
    */
    protected $fillable = [

        'client_id','client_order_id','drivers_app_order_id','minimum_charge','discount_value','payment_status','discount_value_type','tax_value','tax_value_type','deleted_at'
    ];
    protected $hidden = ['deleted_at'];

    ////// WHEN DELETE INVOICE IT WILL DELETE ALL ITEMS :)
    protected static function booted(){

        static::deleting(function($invoice){
            $invoice->items()->delete();
        });
    }
    //////////////////////////
    public function items(){

        return $this->hasMany(InvoiceItem::class,"invoice_id","id");
    }
    public function clientOrder(){

        return $this->hasMany(ClientOrder::class,"order_id","client_order_id");
    }


}
