<?php

namespace App\Models;

use App\Models\Company;
use App\Models\Country;
use App\Http\Traits\FileUploadTrait;
use App\Http\Traits\ImagesTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends Model
{
    use HasFactory;
    use FileUploadTrait;
    use ImagesTrait,SoftDeletes;
    protected $fillable = [

        'id',
        'name_ar',
        'name_en',
        'have_sub_categories',
        'img_path',
        'parent_id',
        'active',
    ];

    protected $hidden = ['pivot', 'deleted_at'];
    public function setImgPathAttribute($value)
    {
        $this->attributes['img_path'] = $this->uploadFile($value,'images/categories', $this->attributes['img_path'] ?? "");
    }

    public function parent(){

        return $this->belongsTo(Category::class,'parent_id','id');
    }

    public function subCategories(){

        return $this->hasMany(Category::class,'parent_id','id');
    }

    // public static function getAllCategoriesWithSubcategories()
    // {
    //     $categories = Category::with('subCategories')->whereNull('parent_id')->get();

    //     $categoriesWithSubcategories = $categories->map(function ($category) {
    //         $category->subCategories = $category->getSubcategoriesRecursively();
    //         return $category;
    //     });

    //     return $categoriesWithSubcategories;
    // }

    // protected function getSubcategoriesRecursively()
    // {
    //     $subcategories = $this->subCategories;

    //     if ($subcategories->isNotEmpty()) {
    //         $subcategories->each(function ($subcategory) {
    //             $subcategory->subCategories = $subcategory->getSubcategoriesRecursively();
    //             unset($subcategory->sub_categories); // Remove the sub_categories attribute
    //         });
    //     }

    //     return $subcategories;
    // }

    public function companies(){

        return $this->belongsToMany(Company::class,'companies_categories','category_id','company_id');
    }

    public function countries(){

        return $this->belongsToMany(Country::class,'categories_countries','category_id','country_id');
    }

}
