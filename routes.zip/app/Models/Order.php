<?php

namespace App\Models;

use App\Http\Traits\ImagesTrait;
use App\Http\Traits\FileUploadTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Exceptions\HttpResponseException;

class Order extends Model
{
    use HasFactory, SoftDeletes;
    use FileUploadTrait;
    use ImagesTrait;

    protected $fillable = [

        'id',
        'role',
        'status',
        'type',
        'special_instructions',
        'comment',
        'pickup_date',
        'delivery_date',
        'pickup_driver_assigned_to_transportation_period_id',
        'delivery_driver_assigned_to_transportation_period_id',

        'actual_delivery_start_date_time',
        'actual_delivery_end_date_time',
        'actual_pickup_start_date_time',
        'actual_pickup_end_date_time',
        'drivers_manger_id',
        'price',
        'discount_value',
        'discount_value_type',
        'drivers_manager_id',
        'created_at',

    ];

    protected $hidden = ['deleted_at'];

    public function deliveryTrasportationPeriodAssignedToDriver()
    {

        return $this->belongsTo(TransportationPeriodAssignedToDriver::class, 'delivery_driver_assigned_to_transportation_period_id', 'id');
    }

    public function pickupTrasportationPeriodAssignedToDriver()
    {

        return $this->belongsTo(TransportationPeriodAssignedToDriver::class, 'pickup_driver_assigned_to_transportation_period_id', 'id');
    }

    public function clientOrder()
    {

        return $this->hasOne(ClientOrder::class, 'order_id', 'id');
    }
    public function driversAppOrder()
    {

        return $this->hasOne(DriversApp\Order::class, 'order_id', 'id');
    }

    public function pickupDriver()
    {

        return $this->belongsTo(Driver::class, 'pickup_driver_id', 'user_id');
    }

    public function deliveryDriver()
    {

        return $this->belongsTo(Driver::class, 'delivery_driver_id', 'user_id');
    }

    public function items()
    {

        return $this->hasMany(OrderItem::class, 'order_id', 'id');
    }

    public function easyOrder()
    {

        return $this->hasOne(EasyOrder::class, 'order_id', 'id');
    }



}
