<?php

namespace App\Http\Requests\Company;

use App\Http\Traits\ResponsesTrait;
use App\Http\Services\Users\CompaniesService;
use App\Http\Requests\User\UserStoreRequest;
use Illuminate\Contracts\Validation\Validator;
use App\Http\Constants\FormRequestRulesConstant;
use Illuminate\Http\Exceptions\HttpResponseException;

class StoreRequest extends UserStoreRequest
{
    use ResponsesTrait;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    private $companiesService;
    public function authorize()
    {
        $this->companiesService = new CompaniesService();
        return $this->companiesService->canUserCreateOrDeleteCompany(request('country_id'));
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {

        return array_merge($this->userRules,[
            'country_id'        => 'required|numeric|exists:countries,id',
            'name_ar'           => 'required|string|max:255',
            'name_en'           => 'required|string|max:255',
            'orders_per_hour'   => 'sometimes|nullable|numeric',
            'logo_path'         => 'required|' . FormRequestRulesConstant::ImageValidation,
            'cover_path'        => 'sometimes|nullable|' . FormRequestRulesConstant::ImageValidation,
        ]);
    }

    public function messages(): array
    {

        return array_merge($this->userMessages,[

            'email.unique'  => __('validation.distinct'),
            'phone.unique'  => __('validation.distinct'),
            'country_id.exists'  => __('validation.id.exists'),
            'country_id.required'  => __('validation.id.required'),
            'name_ar.required'  => __('validation.name_ar.required'),
            'name_en.required'  => __('validation.name_en.required'),
            'orders_per_hour.numeric'  => __('validation.orders_per_hour.numeric'),
            'logo_path.required'  => __('validation.img_path.required'),
        ]);
    }

    public function failedValidation(Validator $validator)
    {

        throw new HttpResponseException($this->apiResponse(null, false, $validator->errors()->first()));
    }
    public function failedAuthorization()
    {

        throw new HttpResponseException($this->apiResponse(data: null, status: false, message: __('auth.authorization.not_authorized')));
    }
}
