<?php

namespace App\Http\Requests\Company;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
use App\Http\Traits\ResponsesTrait;

class ClientRateCompany extends FormRequest
{
    use ResponsesTrait;

    // protected $stopOnFirstFailure = true;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {

        // authorize user
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        return [

            'base_companies_rate_id'    =>  'required|exists:base_companies_rates,id',
            'company_id'                =>  'required|exists:companies,user_id',
            'value'                     =>  'required|numeric|between:1,10',

        ];
    }

    public function messages(): array
    {

        return [
            'base_companies_rate_id.required' => __('validation.base_companies_rate_id.required'),
            'base_companies_rate_id.exists'   => __('validation.base_companies_rate_id.exists'),
            'company_id.required'             => __('validation.company_id.required'),
            'company_id.exists'               => __('validation.company_id.exists'),
            'value.required'                  => __('validation.value.required'),
            'value.numeric'                   => __('validation.value.numeric'),
            'value.between'                   => __('validation.value.between'),
        ];
    }

    public function failedValidation(Validator $validator)
    {

        throw new HttpResponseException($this->apiResponse(null, false, $validator->errors()->first()));
    }

    public function failedAuthorization()
    {

        throw new HttpResponseException($this->apiResponse(data: null, status: false, message: __('auth.authorization.not_authorized')));
    }
}
