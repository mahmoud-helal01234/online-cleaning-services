<?php

namespace App\Http\Services\Products;

use App\Models\Product;
use App\Http\Traits\ResponsesTrait;
use App\Models\CompaniesCategories;
use App\Http\Traits\FileUploadTrait;
use App\Http\Traits\LoggedInUserTrait;
use App\Http\Services\Products\ProductOptionsService;
use Illuminate\Http\Exceptions\HttpResponseException;

class ProductsService
{

    use ResponsesTrait;
    use FileUploadTrait;
    use LoggedInUserTrait;

    public function get($categoryId = null, $companyId = null)
    {

        // $loggedInUser = $this->getLoggedInUser();

        $products = Product::with('options')
        ->when($categoryId != null, function ($query) use ($categoryId) {
            $query->where('category_id', $categoryId);
        })->when($companyId != null, function ($query) use ($companyId) {
            $query->where('company_id', $companyId);
        })->get();

        return $products;
        // return ProductsResource::collection($products);
    }

    public function getById($id)
    {

        $product = Product::find($id);

        if ($product == null)
            throw new HttpResponseException($this->apiResponse(null, false, __('validation.not_exist')));

        return $product;
    }

    public function create($product)
    {

        try {
            $user = $this->getLoggedInUser();
            switch ($user->role){
                case 'company' :
                    if(CompaniesCategories::where('company_id',$user->id)->where('category_id',$product['category_id'])->first() == null)
                        throw new HttpResponseException($this->apiResponse(null, false, __('Your company does not have access to this category')));
                    $product['company_id'] = $user->id;
            }

            $createdProduct = Product::create($product);
            $productOptionsService = new ProductOptionsService();
            $productOptionsService->delete(productId: $createdProduct->id);

            foreach($product['options'] as $productOption){

                $productOptionsService->create([...$productOption,"product_id" => $createdProduct->id]);
            }
            return $createdProduct;

        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(status:false));;
        }
    }

    public function update($newProduct)
    {

        $product = $this->getById($newProduct['id']);
        try {
            // CHECKED IN REQUEST AUTHORIZATION FOR WHO CAN UPDATE
            $product->update($newProduct);
            $productOptionsService = new ProductOptionsService();
            $productOptionsService->delete(productId: $newProduct['id']);

            foreach($newProduct['options'] as $productOption){

                $productOptionsService->create([...$productOption,"product_id" => $newProduct['id']]);
            }
            return $product;
        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(status:false));;
        }
    }

    public function toggleActivation($id, $activationStatus)
    {

        $product = $this->getById($id);
        try {

            $product->update(['active' => $activationStatus]);
        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(status:false));
        }
    }

    public function delete($id)
    {

        try {

            $this->canUserDelete($id);

        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(null, false, __('validation.cannot_delete')));
        }
    }

    public function canUserUpdate($proudctId)
    {

        $proudct = $this->getById($proudctId);
        $user = $this->getLoggedInUser();
        // add country_manager case that he can only add or update only products belongs to company in the country that he manage
        switch ($user->role) {
            case "admin":
                return true;
            case "country_manager":
                return $proudct->company->country_id == $user->countryManager->country_id;
            case "company":
                return $proudct->company_id == $user->id;
        }
    }

    public function canUserDelete($id)
    {
        $product = $this->getById($id);
        $user = $this->getLoggedInUser();

        if ($user->role == "admin" || $product->company_id == $user->id || $product->company->country_id == $user->countryManager->country_id) {


            $productOptionsService = new ProductOptionsService();
            $productOptionsService->delete(productId: $id);
            $product->delete();
        }
        else{
            throw new HttpResponseException($this->apiResponse(null, false, __('you_cannot_delete')));

        }

    }
    public function deleteChildren($categoryId = null , $companyId = null)
    {
        $companiesCategoriesProudcts = Product::where('category_id', $categoryId)->orWhere('company_id', $companyId)->get();
        $productOptionsService = new ProductOptionsService();

        foreach ($companiesCategoriesProudcts as $companiesCategoriesProudct){
            $productOptionsService->delete(productId: $companiesCategoriesProudct->id);
            $companiesCategoriesProudct->delete();
        }
    }
}
