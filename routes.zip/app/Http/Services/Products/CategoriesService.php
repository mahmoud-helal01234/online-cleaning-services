<?php

namespace App\Http\Services\Products;

use Exception;
use App\Models\Category;
use App\Http\Traits\ResponsesTrait;
use App\Http\Traits\FileUploadTrait;
use App\Http\Traits\LoggedInUserTrait;
use Illuminate\Http\Exceptions\HttpResponseException;
use App\Http\Services\Products\CompaniesCategoriesService;

class CategoriesService
{

    use ResponsesTrait;
    use FileUploadTrait;
    use LoggedInUserTrait;

    private $companiesCategoriesService;
    private $proudctsService;
    public function get($countryId = null, $categoryId = null,$parentId = null, $companyId = null)
    {
        // $loggedInUser = $this->getLoggedInUser();
        // dd($loggedInUser);
        // if(isset($loggedInUser->role)){

        //     switch ($loggedInUser->role) {
        //         case "admin":
        //             $data  = Category::where('parent_id', $parentId)->with('parent')->get();
        //             break;
        //     }
        // }else{

            $categories = Category::
            // when($countryId != null, function ($query) use ($countryId) {
            // $query->whereHas('countries', function ($query) use ($countryId) {
            //      $query->where('country_id', $countryId);

            // });
            // }
            // )
            // ->
            when($categoryId != null, function ($query) use ($categoryId) {
                 $query->where('id', $categoryId);
            })
            -> when($companyId != null, function ($query) use ($companyId) {
                $query->whereHas('companies', function ($query) use ($companyId) {
                    $query->where('company_id', $companyId);
                });
           })
            ->where('parent_id', $parentId)
            ->select('categories.id', 'name_ar', 'name_en', 'img_path', 'have_sub_categories')
            ->get();

            $data['categories'] = $categories;

            if ($parentId != null) {
                $data['parent'] = Category::where('id', $parentId)->select('id', 'name_ar', 'name_en', 'img_path', 'have_sub_categories')->get();
            }
        return $data;

    }
    public function getCategoriesWithSubcategories()
    {
        $categories = Category::with('subCategories')->whereNull('parent_id')->get();

        $categoriesWithSubcategories = $categories->map(function ($category) {
            $category->subCategories = $this->getSubcategoriesRecursively($category->subCategories);
            return $category;
        });

        return $categoriesWithSubcategories;
    }

    protected function getSubcategoriesRecursively($subcategories)
    {
        if ($subcategories->isNotEmpty()) {
            $subcategories->each(function ($subcategory) {
                $subcategory->subCategories = $this->getSubcategoriesRecursively($subcategory->subCategories);
                unset($subcategory->sub_categories); // Remove the sub_categories attribute
            });
        }

        return $subcategories;
    }

    public function categoryParent($categoryId)
    {
        $category = Category::find($categoryId);
        $categoryParent = $category->parent;
        return $categoryParent;
    }
    public function selectCategories($companyId = null, $haveSubCategories = null, $parentId = null)
    {
        $categories = Category::with('companies');
        if ($companyId != null)
            $categories = $categories->whereHas('companies', function ($query) use ($companyId) {
                $query->where('company_id', $companyId);
            });
        if ($haveSubCategories != null)
            $categories = $categories->where('have_sub_categories', $haveSubCategories);
        if ($parentId != null)
            $categories = $categories->where('parent_id', $parentId);

        $categories = $categories->get();
        return $categories;
    }

    public function getById($id)
    {

        $category = Category::find($id);

        if ($category == null)
            throw new HttpResponseException($this->apiResponse(null, false, __('validation.not_exist')));
        return $category;
    }



    public function create($category)
    {

        try {

            Category::create($category);
        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(status:false));;
        }
    }


    public function update($newCategory)
    {

        $category = $this->getById($newCategory['id']);



        // validate if parent same as edited
        if (isset($newCategory['parent_id']) && $newCategory['id'] == $newCategory['parent_id'])
            throw new HttpResponseException($this->apiResponse(null, false,__('validation.same_parent')));

        try {
            $category->update($newCategory);
            return $category;
        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(status:false));;
        }
    }

    public function toggleActivation($id, $activationStatus)
    {

        $category = $this->getById($id);
        try {

            $category->update(['active' => $activationStatus]);
        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(status:false));;
        }
    }

    public function delete($id)
    {
        $loggedInUser = $this->getLoggedInUser();
        $category = $this->getById($id);

        //  OLD CODE WITHOUT RECURSION
        /*
                if($category->subCategories()->count() > 0 ) {
                    $subCategories = $category->subCategories;
                    //dd($subCategories);

                    foreach ($subCategories as $subCategory) {
                        // need recurion to delete all subcategories .....
                        if($subCategory->subCategories()->count() > 0){

                            $secondSubCategories = $subCategory->subCategories;

                            foreach ($secondSubCategories as $secondSubCategory) {
                                $this->deleteChildren($secondSubCategory);
                            }
                    }
                        ///
                        $this->deleteChildren($subCategory);
                    }
                }else{
                    $this->deleteChildren($category);
                }
        */

        $categoriesToDelete = [$category];
        while (!empty($categoriesToDelete)) {
            $currentCategory = array_shift($categoriesToDelete);

            if ($currentCategory->subCategories()->count() > 0) {
                $subCategories = $currentCategory->subCategories;
                $categoriesToDelete = array_merge($categoriesToDelete, $subCategories->all());
            }
            $this->deleteRelationsWithCategory($currentCategory);
            $currentCategory->delete();
        }

            //  WE USE SOFT DELETES AND ITS MAY BE RESTORED LATER
            //$imgPath = $category->img_path;
            //$this->deleteFile($imgPath);

            try {
        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(null, false, __('validation.cannot_delete')));
        }
    }


    // public function canUserUpdate($user, $categoryId)
    // {

    //     // only admin can add or update any category so make it in  api.php not here
    //     $category = $this->getById($categoryId);
    //     switch ($user->role) {
    //         case "admin":
    //             return true;

    //     default:
    //         // test this on the other roles and see the database to know if categories table have user_id
    //         return $category->user_id == $user->id;

    //     }
    // }
    // public function canUserDelete($user, $category)
    // {

    //     if ($user->role == "admin"/* || $category->user_id == $user->id*/) {
    //       return true;
    //     }
    // }
    public function deleteRelationsWithCategory($category){

        $this->companiesCategoriesService = new CompaniesCategoriesService;
        $this->companiesCategoriesService->deleteChildren(categoryId: $category->id);

        $this->proudctsService = new ProductsService;
        $this->proudctsService->deleteChildren(categoryId: $category->id);

    }
}
