<?php

namespace App\Http\Services\Users;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use App\Http\Traits\ResponsesTrait;
use App\Http\Traits\ArraySliceTrait;
use App\Http\Traits\FileUploadTrait;
use App\Http\Traits\LoggedInUserTrait;
use App\Models\DeviceToken;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Exceptions\HttpResponseException;

class UsersService
{

    use ResponsesTrait;
    use FileUploadTrait;
    use ArraySliceTrait;
    use LoggedInUserTrait;

    public function getSelect($active = null, $roles = null)
    {

        $users = User::when($roles != null, function ($query) use ($roles) {

            is_array($roles) ? $query->whereIn('role', $roles) : $query->where('role', $roles);

        })->when($active != null, function ($query) use ($active) {

            $query->where('active', $active);

        })->select(
            "id",
                "name",
                "email",
                "phone"
            )->get();

        return $users;
    }

    public function get($active = null, $role = null)
    {

        $users = User::when($role != null, function ($query) use ($role) {

            is_array($role) ? $query->whereIn('role', $role) : $query->where('role', $role);

        })->when($active != null, function ($query) use ($active) {

            $query->where('active', $active);

        })->get();

        return $users;
    }

    public function getById($id)
    {

        $user = User::find($id);
        if ($user == null)
            throw new HttpResponseException($this->apiResponse(null, false, __('validation.not_exist')));

        return $user;
    }

    public function create($user, $role = 'driver')
    {

        try {

            $user['role'] = $role;
            $createdUser = User::create($user);
            return $createdUser;
        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(status: false));
            ;
        }
    }

    public function createDeviceToken($deviceToken)
    {

        $user = $this->getLoggedInUser();
        $data['user_id'] = $user->id;
        $data['device_token'] = $deviceToken;

        try {

              // Update or create the device token based on the user ID
                DeviceToken::updateOrCreate(['user_id' => $user->id], $data);
            return true;
        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(status: false));

        }
    }
    public function update($newUser)
    {

        $user = $this->getById($newUser['id']);

        try {

            $user->update($newUser);
            return $user;
        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(status: false));
            ;
        }
    }

    public function delete($id, $softDelete = true)
    {
        try {

            if ($softDelete) {

                $user = $this->getById($id);

                // if($this->isAdmin($id))
                //     throw new HttpResponseException($this->apiResponse(null, false, __('validation.cannot_delete')));



                $user->delete();


            } else {

                DB::table('users')->where('id', $id)->delete();
            }
        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(null, false, __('validation.cannot_delete')));
        }
    }

    public function toggleActivation($id, $activationStatus)
    {

        $user = $this->getById($id);
        $user->update(['active' => $activationStatus]);

        try {

            $user->update(['active' => $activationStatus]);

        } catch (\Exception $ex) {

            throw new HttpResponseException($this->apiResponse(null, false, __('validation.cannot_delete')));
        }
    }

    private function hashPassword($password)
    {

        return Hash::make($password);
    }

    public function canUserEditUser($user, $userId)
    {


        $affectedUser = $this->getById($userId);
        if ($user->id == $userId)
            return true;
        switch ($user->role) {

            case "admin":
                return true;
            case "country_manager":
                if (
                    $affectedUser->role == "company" && $affectedUser->company->country_id == $user->countryManager->country_id
                    || ($affectedUser->role == "drivers_manager" && $affectedUser->driversManager->country_id == $user->countryManager->country_id)
                    || ($affectedUser->role == "driver" && $affectedUser->driver->manager_id->country_id == $user->countryManager->country_id)
                )
                    return true;
                break;
            case "company":
            case "drivers_manager":

                if (
                    $affectedUser->role == "driver" &&
                    $affectedUser->driver->manager_id == $user->id
                )
                    return true;
                break;
        }
        return false;

    }
    public function canUserDeleteUser($user, $userId)
    {


        $userToUpdate = $this->getById($userId);
        switch ($user->role) {

            case "admin":
                return true;
            case "company":
            case "drivers_manager":


                if (
                    $userToUpdate->role == "driver" &&
                    $userToUpdate->driver->manager_id == $user->id
                )
                    return true;
                break;
        }
        return false;

    }
}
